package com.im.dataprovider;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SignInTest {
	WebDriver driver;

	@BeforeMethod
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\drivers\\chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://qdcstage.intuitmarket.intuit.com/");

	}

	@DataProvider
	public Iterator<Object[]> getTestData() {
		ArrayList<Object[]> testData = TestUtil.getDataFromExcel();
		return testData.iterator();
	}

	@Test(dataProvider = "getTestData")
	public void signInPageTest(String userName, String passWord) {

		driver.findElement(By.id("signInLinkWidget")).click();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ius-sign-in")));
		driver.findElement(By.id("ius-userid")).sendKeys(userName);
		driver.findElement(By.id("ius-password")).sendKeys(passWord);
		driver.findElement(By.id("ius-sign-in-submit-btn")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Order Number\"]")));

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
