package com.im.dataprovider;

import java.util.ArrayList;

import com.im.qa.util.Xls_Reader;

public class TestUtil {

	static Xls_Reader reader;

	public static ArrayList<Object[]> getDataFromExcel() {

		ArrayList<Object[]> myData = new ArrayList<Object[]>();
		try {

			reader = new Xls_Reader(
					"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");

		} catch (Exception e) {
			e.printStackTrace();
		}

		for (int rowNum = 2; rowNum <= reader.getRowCount("SignIn"); rowNum++) {
			
			String userName = reader.getCellData("SignIn", "Username", rowNum);
			String passWord = reader.getCellData("SignIn", "Password", rowNum);
			
			Object ob[] = {userName, passWord};
			myData.add(ob);

		}
		
		return myData;

	}

}
