package com.im.qa.util.temp;

import com.im.qa.util.Xls_Reader;

public class ExcelOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Excel operations like getRowCount, getColumnCount, addSheet
		Xls_Reader reader = new Xls_Reader(
				"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");
		int columnCount = reader.getColumnCount("Details");
		System.out.println("Coulmn Count: "+columnCount);
		int rowCount = reader.getRowCount("Details");
		System.out.println("Row Count: "+rowCount);
		
		if(!reader.isSheetExist("New_Sandbox")) {
			
			reader.addSheet("New_Sandbox");
		}
		
	}

}
