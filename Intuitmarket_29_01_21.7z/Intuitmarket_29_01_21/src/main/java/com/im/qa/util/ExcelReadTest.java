package com.im.qa.util;

import com.im.qa.base.TestBase;

public class ExcelReadTest extends TestBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Xls_Reader reader = new Xls_Reader(
				"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");
		String firstName = reader.getCellData("Details", "Firstname", 2);
		String lastName = reader.getCellData("Details", "Lastname", 2);
		String city = reader.getCellData("Details", "City", 2);
		String state = reader.getCellData("Details", "State", 2);
		String country = reader.getCellData("Details", "Country", 2);

		System.out.println(firstName);
		System.out.println(lastName);
		System.out.println(city);
		System.out.println(state);
		System.out.println(country);

	}

}
