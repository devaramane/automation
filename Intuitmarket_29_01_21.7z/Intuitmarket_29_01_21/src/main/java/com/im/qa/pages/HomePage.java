package com.im.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.im.qa.base.TestBase;
import com.im.qa.util.Xls_Reader;

public class HomePage extends TestBase {

	// Page Factory - OR
	@FindBy(xpath = "//div[@data-wa-link=\"intuit logo\"]")
	WebElement imLogo;

	@FindBy(xpath = "//a[@data-wa-link=\"hdr-checks:all checks\"]")
	WebElement allChecks;

	@FindBy(id = "signInLinkWidget")
	WebElement signIn;

	@FindBy(id = "ius-sign-in")
	WebElement signInPopUp;

	@FindBy(id = "ius-userid")
	WebElement userID;

	@FindBy(id = "ius-password")
	WebElement password;

	@FindBy(id = "ius-sign-in-submit-btn")
	WebElement signInBtn;

	@FindBy(xpath = "//input[@placeholder=\"Order Number\"]")
	WebElement orderNumField;

	@FindBy(xpath = "//a[contains(text(),'My Account')]")
	WebElement myAccount;

	@FindBy(xpath = "//a[contains(text(),'Sign Out')]")
	WebElement signOut;

	// Initializing Object Repository (OR)
	public HomePage() {
		PageFactory.initElements(driver, this);

	}

	public String validateIMHomePageTitle() {
		return driver.getTitle();
	}

	public boolean validateIMLogo() {
		return imLogo.isDisplayed();
	}

	public AllChecksPage gotoAllChecksPage() throws InterruptedException {
//		Implemented Explicit wait
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@data-wa-link=\"hdr-checks:all checks\"]")));
		allChecks.click();
		return new AllChecksPage();

	}

	public boolean homePageSignInPopUp() throws InterruptedException {

		signIn.click();
		Thread.sleep(10000);
		return signInPopUp.isDisplayed();

	}

	public OrderHistoryPage signInFromHomePage() {
//		Pass Credentials through Properties file
//		signIn.click();
//		WebDriverWait wait = new WebDriverWait(driver, 20);
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ius-sign-in")));
//		userID.sendKeys(prop.getProperty("username"));
//		password.sendKeys(prop.getProperty("password"));
//		signInBtn.click();
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Order Number\"]")));
//		return new OrderHistoryPage();

//		 Read data from excel, Explicit wait & Exception handling

		signIn.click();
		WebDriverWait wait1 = new WebDriverWait(driver, 20);
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.id("ius-sign-in")));
		try {
			Xls_Reader reader = new Xls_Reader(
					"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");
			String userName = reader.getCellData("SignIn", "Username", 2);
			String pwd = reader.getCellData("SignIn", "Password", 2);
			userID.sendKeys(userName);
			password.sendKeys(pwd);
			signInBtn.click();
		} catch (Exception e) {
			e.printStackTrace();
		}

		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Order Number\"]")));
		return new OrderHistoryPage();

	}

//	 Data Driven - Parameterization
	public void testDataDriven() throws InterruptedException {
//		signIn.click();
//		WebDriverWait wait = new WebDriverWait(driver, 20);
//		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ius-sign-in")));
		Xls_Reader reader = new Xls_Reader(
				"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");
		int rowCount = reader.getRowCount("SignIn");
		for (int rowNum = 2; rowNum <= rowCount; rowNum++) {
			String userName = reader.getCellData("SignIn", "Username", rowNum);
			String passWord = reader.getCellData("SignIn", "Password", rowNum);
//			System.out.println(userName+" "+passWord);
			if (rowNum == 4) {
				break;
			}
			signIn.click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("ius-sign-in")));
			userID.clear();
			userID.sendKeys(userName);
			password.clear();
			password.sendKeys(passWord);
			signInBtn.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@placeholder=\"Order Number\"]")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'My Account')]")));
			myAccount.click();
			Thread.sleep(5000);
			signOut.click();
			Thread.sleep(5000);
			driver.navigate().to("https://qdcstage.intuitmarket.com/");

		}

	}

}
