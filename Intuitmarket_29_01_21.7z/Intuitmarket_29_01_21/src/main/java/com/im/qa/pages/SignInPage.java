package com.im.qa.pages;

import com.im.qa.base.TestBase;

public class SignInPage extends TestBase {

}
