package com.im.qa.pages;

public class OrderHistoryPage {

}
