package com.im.qa.util.temp;

import com.im.qa.base.TestBase;
import com.im.qa.util.Xls_Reader;

public class ParameterizationTest extends TestBase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Xls_Reader reader = new Xls_Reader(
				"C:\\Users\\vdevaramane\\eclipse-workspace\\Intuitmarket\\src\\main\\java\\com\\im\\qa\\util\\Sandbox.xlsx");
//		Write Operation setCellData, addColumn
		int rowCount = reader.getRowCount("SignIn");
//		System.out.println("Row Count:"+rowCount);
		reader.addColumn("SignIn", "Status");
		for (int rowNum = 2; rowNum <= rowCount; rowNum++) {
			String userName = reader.getCellData("SignIn", "Username", rowNum);
			String passWord = reader.getCellData("SignIn", "Password", rowNum);
			if(rowNum==4) {
				break;
			}
			System.out.println(userName+" "+passWord);
			reader.setCellData("SignIn", "Status", rowNum, "Pass");
			
			
			
		}

	}

}
