package com.im.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.im.qa.base.TestBase;
import com.im.qa.pages.HomePage;

public class HomePageTest extends TestBase {

	HomePage homePage;

	public HomePageTest() {
		super();
	}

	@BeforeMethod
	public void setup() {
		initialization();
		homePage = new HomePage();
	}

	@Test
	public void validateIMHomePageTitleTest() {
		String title = homePage.validateIMHomePageTitle();
		Assert.assertEquals(title, "Small Business Supplies from Intuit Market | QuickBooks");
	}

	@Test
	public void validateIMLogoTest() {
		homePage.validateIMLogo();
		Assert.assertEquals(true, true);
	}

	@Test
	public void gotoAllChecksPageTest() throws InterruptedException {
		homePage.gotoAllChecksPage();
		String url = driver.getCurrentUrl();
		Assert.assertEquals(url, "https://qdcstage.intuitmarket.intuit.com/checks");
	}

	@Test
	public void homePageSignInPopUpTest() throws InterruptedException {
		homePage.homePageSignInPopUp();
		Assert.assertEquals(true, true);

	}

	@Test
	public void signInFromHomePageTest() {
		homePage.signInFromHomePage();
		String url = driver.getCurrentUrl();
		Assert.assertEquals(url, "https://qdcstage.intuitmarket.intuit.com/orderhistory");

	}
	@Test
	public void testDataDrivenTest() throws InterruptedException {
		homePage.testDataDriven();
		
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
